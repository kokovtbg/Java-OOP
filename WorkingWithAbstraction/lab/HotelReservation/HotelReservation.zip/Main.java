package WorkingWithAbstraction.HotelReservation;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine();
        String[] data = input.split("\\s+");
        double pricePerDay = Double.parseDouble(data[0]);
        int days = Integer.parseInt(data[1]);
        String season = data[2];
        String discountType = data[3];
        int multiplier = 0;
        if (season.equals("Autumn")) {
            multiplier = PriceCalculator.Season.Autumn.getMultiplier();
        } else if (season.equals("Spring")) {
            multiplier = PriceCalculator.Season.Spring.getMultiplier();
        } else if (season.equals("Winter")) {
            multiplier = PriceCalculator.Season.Winter.getMultiplier();
        } else if (season.equals("Summer")) {
            multiplier = PriceCalculator.Season.Summer.getMultiplier();
        }
        double discount = 0;
        if (discountType.equals("VIP")) {
            discount = PriceCalculator.DiscountType.VIP.getDiscount();
        } else if (discountType.equals("SecondVisit")) {
            discount = PriceCalculator.DiscountType.SecondVisit.getDiscount();
        } else if (discountType.equals("None")) {
            discount = PriceCalculator.DiscountType.None.getDiscount();
        }
        System.out.printf("%.2f", pricePerDay * days * multiplier * discount);
    }
}
