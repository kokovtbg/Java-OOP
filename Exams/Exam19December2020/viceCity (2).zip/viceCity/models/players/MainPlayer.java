package viceCity.models.players;

public class MainPlayer extends BasePlayer {
    private static final int INITIAL_LIFE_POINTS = 100;
    private static final String NAME_MAIN_PLAYER = "Tommy Vercetti";

    public MainPlayer() {
        super(NAME_MAIN_PLAYER, INITIAL_LIFE_POINTS);
    }
}
