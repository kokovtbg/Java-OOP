package glacialExpedition.models.explorers;

import glacialExpedition.models.suitcases.Suitcase;

public class GlacierExplorer extends BaseExplorer {
    private static final int INITIAL_ENERGY = 40;

    public GlacierExplorer(String name) {
        super(name, INITIAL_ENERGY);
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public double getEnergy() {
        return 0;
    }

    @Override
    public Suitcase getSuitcase() {
        return null;
    }
}
