package glacialExpedition.models.explorers;

import glacialExpedition.models.suitcases.Suitcase;

public class NaturalExplorer extends BaseExplorer {
    private static final int INITIAL_ENERGY = 60;
    private static final int ENERGY_DECREASE = 7;

    public NaturalExplorer(String name) {
        super(name, INITIAL_ENERGY);
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public double getEnergy() {
        return 0;
    }

    @Override
    public Suitcase getSuitcase() {
        return null;
    }

    @Override
    public void search() {
        setEnergy(getEnergy() - ENERGY_DECREASE);
    }
}
