package glacialExpedition.models.mission;

import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.states.State;
import glacialExpedition.repositories.ExplorerRepository;

import java.util.Collection;
import java.util.List;

public class MissionImpl implements Mission {

    @Override
    public void explore(State state, Collection<Explorer> explorers) {
        ExplorerRepository explorerRepository = new ExplorerRepository();
        explorers.addAll(explorerRepository.getCollection());
        explorers
                .forEach(e -> {
                    if (e.canSearch() && !state.getExhibits().isEmpty()) {
                        e.search();
                        e.getSuitcase().getExhibits().add(((List<String>) state.getExhibits()).remove(0));
                    }
                });
    }
}
