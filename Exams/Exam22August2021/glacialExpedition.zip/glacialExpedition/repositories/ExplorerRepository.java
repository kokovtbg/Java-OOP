package glacialExpedition.repositories;

import glacialExpedition.models.explorers.Explorer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ExplorerRepository implements Repository<Explorer> {
    private List<Explorer> explorers;

    public ExplorerRepository() {
        this.explorers = new ArrayList<>();
    }

    @Override
    public Collection<Explorer> getCollection() {
        return Collections.unmodifiableList(this.explorers);
    }

    @Override
    public void add(Explorer explorer) {
        this.explorers.add(explorer);
    }

    @Override
    public boolean remove(Explorer explorer) {
        return this.explorers.remove(explorer);
    }

    @Override
    public Explorer byName(String name) {
        for (int i = 0; i < this.explorers.size(); i++) {
            if (this.explorers.get(i).getName().equals(name)) {
                return this.explorers.get(i);
            }
        }
        return null;
    }
}
