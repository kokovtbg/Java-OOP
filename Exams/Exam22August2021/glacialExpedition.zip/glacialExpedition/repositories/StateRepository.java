package glacialExpedition.repositories;

import glacialExpedition.models.states.State;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class StateRepository implements Repository<State> {
    private List<State> states;

    @Override
    public Collection<State> getCollection() {
        return Collections.unmodifiableList(this.states);
    }

    @Override
    public void add(State state) {
        this.states.add(state);
    }

    @Override
    public boolean remove(State state) {
        return this.states.remove(state);
    }

    @Override
    public State byName(String name) {
        for (int i = 0; i < this.states.size(); i++) {
            if (this.states.get(i).getName().equals(name)) {
                return this.states.get(i);
            }
        }
        return null;
    }
}
