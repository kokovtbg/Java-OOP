package bakery.common.enums;

public enum DrinkType {
    Tea,
    Water
}
