package bakery.core;

import bakery.common.ExceptionMessages;
import bakery.common.OutputMessages;
import bakery.core.interfaces.Controller;
import bakery.repositories.entities.bakedFoods.interfaces.BakedFood;
import bakery.repositories.entities.bakedFoods.Bread;
import bakery.repositories.entities.bakedFoods.Cake;
import bakery.repositories.entities.drinks.interfaces.Drink;
import bakery.repositories.entities.drinks.Tea;
import bakery.repositories.entities.drinks.Water;
import bakery.repositories.entities.tables.InsideTable;
import bakery.repositories.entities.tables.OutsideTable;
import bakery.repositories.entities.tables.interfaces.Table;
import bakery.repositories.interfaces.DrinkRepository;
import bakery.repositories.interfaces.FoodRepository;
import bakery.repositories.interfaces.TableRepository;

import java.util.List;
import java.util.stream.Collectors;

public class ControllerImpl implements Controller {
    private FoodRepository<BakedFood> foodRepository;
    private DrinkRepository<Drink> drinkRepository;
    private TableRepository<Table> tableRepository;
    private static double totalBills;

    public ControllerImpl(FoodRepository<BakedFood> foodRepository, DrinkRepository<Drink> drinkRepository, TableRepository<Table> tableRepository) {
        this.foodRepository = foodRepository;
        this.drinkRepository = drinkRepository;
        this.tableRepository = tableRepository;
        totalBills = 0;
    }


    @Override
    public String addFood(String type, String name, double price) {
        //TODO:
        BakedFood food = null;
        switch (type) {
            case "Bread":
                food = new Bread(name, price);
                break;
            case "Cake":
                food = new Cake(name, price);
                break;
        }
        BakedFood foodInRepo = foodRepository.getByName(name);
        if (foodInRepo != null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST, type, name));
        }
        foodRepository.add(food);
        return String.format(OutputMessages.FOOD_ADDED, name, type);
    }

    @Override
    public String addDrink(String type, String name, int portion, String brand) {
        //TODO:
        Drink drink = null;
        switch (type) {
            case "Tea":
                drink = new Tea(name, portion, brand);
                break;
            case "Water":
                drink = new Water(name, portion, brand);
                break;
        }
        Drink drinkInRepo = drinkRepository.getAll().stream()
                .filter(d -> d.getName().equals(name)).findFirst().orElse(null);
        if (drinkInRepo != null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST, type, name));
        }
        drinkRepository.add(drink);
        return String.format(OutputMessages.DRINK_ADDED, name, brand);
    }

    @Override
    public String addTable(String type, int tableNumber, int capacity) {
        //TODO:
        Table table = null;
        switch (type) {
            case "InsideTable":
                table = new InsideTable(tableNumber, capacity);
                break;
            case "OutsideTable":
                table = new OutsideTable(tableNumber, capacity);
                break;
        }
        Table tableInRepo = tableRepository.getByNumber(tableNumber);
        if (tableInRepo != null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.TABLE_EXIST, tableNumber));
        }
        tableRepository.add(table);
        return String.format(OutputMessages.TABLE_ADDED, tableNumber);
    }

    @Override
    public String reserveTable(int numberOfPeople) {
        //TODO:
        Table tableInRepo = tableRepository.getAll().stream()
                .filter(t -> !t.isReserved() && t.getCapacity() >= numberOfPeople)
                .findFirst().orElse(null);
        if (tableInRepo == null) {
            return String.format(OutputMessages.RESERVATION_NOT_POSSIBLE, numberOfPeople);
        }
        tableInRepo.reserve(numberOfPeople);
        return String.format(OutputMessages.TABLE_RESERVED, tableInRepo.getTableNumber(), numberOfPeople);
    }

    @Override
    public String orderFood(int tableNumber, String foodName) {
        //TODO:
        Table tableInRepo = tableRepository.getByNumber(tableNumber);
        if (tableInRepo == null) {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }
        BakedFood foodInRepo = foodRepository.getByName(foodName);
        if (foodInRepo == null) {
            return String.format(OutputMessages.NONE_EXISTENT_FOOD, foodName);
        }
        if (tableInRepo.isReserved()) {
            tableInRepo.orderFood(foodInRepo);
            return String.format(OutputMessages.FOOD_ORDER_SUCCESSFUL, tableNumber, foodName);
        } else {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }
    }

    @Override
    public String orderDrink(int tableNumber, String drinkName, String drinkBrand) {
        //TODO:
        Table tableInRepo = tableRepository.getByNumber(tableNumber);
        if (tableInRepo == null) {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }
        Drink drinkInRepo = drinkRepository.getByNameAndBrand(drinkName, drinkBrand);
        if (drinkInRepo == null) {
            return String.format(OutputMessages.NON_EXISTENT_DRINK, drinkName, drinkBrand);
        }
        if (tableInRepo.isReserved()) {
            tableInRepo.orderDrink(drinkInRepo);
            return String.format(OutputMessages.DRINK_ORDER_SUCCESSFUL, tableNumber, drinkName, drinkBrand);
        } else {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }
    }

    @Override
    public String leaveTable(int tableNumber) {
        //TODO:
        Table table = tableRepository.getByNumber(tableNumber);
        StringBuilder builder = new StringBuilder();
        builder.append(String.format(OutputMessages.BILL, tableNumber, table.getBill()));
        builder.append(System.lineSeparator());
        totalBills += table.getBill();
        table.clear();
        return builder.toString().trim();
    }

    @Override
    public String getFreeTablesInfo() {
        //TODO:
        StringBuilder builder = new StringBuilder();
        List<Table> freeTables = tableRepository.getAll().stream()
                .filter(t -> !t.isReserved()).collect(Collectors.toList());
        for (Table table : freeTables) {
            builder.append(table.getFreeTableInfo());
            builder.append(System.lineSeparator());
        }
        return builder.toString().trim();
    }

    @Override
    public String getTotalIncome() {
        //TODO:
        return String.format(OutputMessages.TOTAL_INCOME, totalBills);
    }
}
