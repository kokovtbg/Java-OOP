package bakery;

import bakery.core.ControllerImpl;
import bakery.core.EngineImpl;
import bakery.core.interfaces.Controller;
import bakery.repositories.DrinkRepositoryImpl;
import bakery.repositories.FoodRepositoryImpl;
import bakery.repositories.TableRepositoryImpl;
import bakery.repositories.entities.bakedFoods.interfaces.BakedFood;
import bakery.repositories.entities.drinks.interfaces.Drink;
import bakery.repositories.entities.tables.interfaces.Table;
import bakery.io.ConsoleReader;
import bakery.io.ConsoleWriter;
import bakery.repositories.interfaces.*;

public class Main {
    public static void main(String[] args) {

        FoodRepository<BakedFood> foodRepository = new FoodRepositoryImpl(); // TODO:  new FoodRepositoryImpl<>();
        DrinkRepository<Drink> drinkRepository = new DrinkRepositoryImpl();  // TODO:  new DrinkRepositoryImpl<>();
        TableRepository<Table> tableRepository = new TableRepositoryImpl(); // TODO:  new TableRepositoryImpl<>();

        Controller controller = new ControllerImpl(foodRepository, drinkRepository, tableRepository); // TODO: new ControllerImpl(foodRepository, drinkRepository, tableRepository);

        // TODO:OPTIONAL
        ConsoleReader reader = new ConsoleReader();
        ConsoleWriter writer = new ConsoleWriter();
        EngineImpl engine = new EngineImpl(reader, writer, controller);
        engine.run();
    }
}
