package Reflection.exercise.HarvestingFields.harvestingFields;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		Class<RichSoilLand> richSoilLandClass = RichSoilLand.class;
		Field[] fields = richSoilLandClass.getDeclaredFields();

		String input = scan.nextLine();
		while (!input.equals("HARVEST")) {
			switch (input) {
				case "private":
					Arrays.stream(fields).filter(f -> Modifier.isPrivate(f.getModifiers())).forEach(f -> System.out.printf("%s %s %s%n", "private", f.getType().getSimpleName(), f.getName()));
					break;
				case "protected":
					Arrays.stream(fields).filter(f -> Modifier.isProtected(f.getModifiers())).forEach(f -> System.out.printf("%s %s %s%n", "protected", f.getType().getSimpleName(), f.getName()));
					break;
				case "public":
					Arrays.stream(fields).filter(f -> Modifier.isPublic(f.getModifiers())).forEach(f -> System.out.printf("%s %s %s%n", "public", f.getType().getSimpleName(), f.getName()));
					break;
				case "all":
					Arrays.stream(fields).forEach(f -> {
						if (Modifier.isPrivate(f.getModifiers())) {
							System.out.printf("%s %s %s%n", "private", f.getType().getSimpleName(), f.getName());
						} else if (Modifier.isProtected(f.getModifiers())) {
							System.out.printf("%s %s %s%n", "protected", f.getType().getSimpleName(), f.getName());
						} else if (Modifier.isPublic(f.getModifiers())) {
							System.out.printf("%s %s %s%n", "public", f.getType().getSimpleName(), f.getName());
						}
					});
					break;
			}

			input = scan.nextLine();
		}
	}
}
