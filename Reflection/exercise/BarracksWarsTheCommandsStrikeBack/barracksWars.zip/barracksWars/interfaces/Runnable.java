package Reflection.exercise.BarracksWarsTheCommandsStrikeBack.barracksWars.interfaces;

public interface Runnable {
	void run();
}
