package Reflection.exercise.BarracksWarsTheCommandsStrikeBack.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
