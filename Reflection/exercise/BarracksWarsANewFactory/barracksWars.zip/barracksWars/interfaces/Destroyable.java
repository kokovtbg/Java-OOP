package Reflection.exercise.BarracksWarsANewFactory.barracksWars.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
