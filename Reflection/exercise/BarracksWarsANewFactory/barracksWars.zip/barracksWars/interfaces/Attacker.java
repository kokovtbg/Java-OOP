package Reflection.exercise.BarracksWarsANewFactory.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
