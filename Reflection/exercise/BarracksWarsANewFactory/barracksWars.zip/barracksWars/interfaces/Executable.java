package Reflection.exercise.BarracksWarsANewFactory.barracksWars.interfaces;

public interface Executable {

	String execute();

}
