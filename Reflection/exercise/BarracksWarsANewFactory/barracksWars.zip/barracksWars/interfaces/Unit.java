package Reflection.exercise.BarracksWarsANewFactory.barracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
