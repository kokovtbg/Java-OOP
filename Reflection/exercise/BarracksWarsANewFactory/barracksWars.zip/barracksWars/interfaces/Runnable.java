package Reflection.exercise.BarracksWarsANewFactory.barracksWars.interfaces;

public interface Runnable {
	void run();
}
