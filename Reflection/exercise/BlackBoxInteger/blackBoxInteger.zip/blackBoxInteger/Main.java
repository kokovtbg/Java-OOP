package Reflection.exercise.BlackBoxInteger.blackBoxInteger;


import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IllegalAccessException, InvocationTargetException, InstantiationException, NoSuchMethodException {
        Scanner scan = new Scanner(System.in);
        Class<BlackBoxInt> blackBoxIntClass = BlackBoxInt.class;

        Constructor<?>[] declaredConstructors = blackBoxIntClass.getDeclaredConstructors();
        Constructor<?> declaredConstructor = declaredConstructors[1];
        declaredConstructor.setAccessible(true);
        BlackBoxInt blackBoxInt = (BlackBoxInt) declaredConstructor.newInstance();

        Method[] declaredMethods = blackBoxIntClass.getDeclaredMethods();
        Arrays.stream(declaredMethods).forEach(m -> m.setAccessible(true));
        
        String input = scan.nextLine();
        while (!input.equals("END")) {
            String[] commandParts = input.split("_");
            String command = commandParts[0];
            int number = Integer.parseInt(commandParts[1]);

            switch (command) {
                case "add":
                    operation(blackBoxInt, declaredMethods, "add", number);
                    break;
                case "subtract":
                    operation(blackBoxInt, declaredMethods, "subtract", number);
                    break;
                case "multiply":
                    operation(blackBoxInt, declaredMethods, "multiply", number);
                    break;
                case "divide":
                    operation(blackBoxInt, declaredMethods, "divide", number);
                    break;
                case "leftShift":
                    operation(blackBoxInt, declaredMethods, "leftShift", number);
                    break;
                case "rightShift":
                    operation(blackBoxInt, declaredMethods, "rightShift", number);
                    break;
            }

            input = scan.nextLine();
        }
    }

    private static void operation(BlackBoxInt blackBoxInt, Method[] declaredMethods, String operation, int number) throws IllegalAccessException, InvocationTargetException {
        for (Method m : declaredMethods) {
            if (m.getName().equals(operation)) {
                m.invoke(blackBoxInt, number);
            }
        }
        Field[] fields = BlackBoxInt.class.getDeclaredFields();
        Arrays.stream(fields).filter(f -> f.getName().equals("innerValue")).forEach(f -> f.setAccessible(true));
        int innerValue = (int) fields[1].get(blackBoxInt);
        System.out.println(innerValue);
    }
}
