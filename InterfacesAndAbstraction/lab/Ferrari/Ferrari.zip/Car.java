//package InterfacesAndAbstraction.lab.Ferrari;

public interface Car {

    String brakes();
    String gas();
}
