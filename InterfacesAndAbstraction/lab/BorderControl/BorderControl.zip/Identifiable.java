//package InterfacesAndAbstraction.lab.BorderControl;

public interface Identifiable {
    String getId();
}
