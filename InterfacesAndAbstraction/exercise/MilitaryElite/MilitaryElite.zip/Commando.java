package InterfacesAndAbstraction.exercise.MilitaryElite;

public interface Commando extends SpecialisedSoldier {
    void completeMission(String mission);
}
