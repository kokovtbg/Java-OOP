package InterfacesAndAbstraction.exercise.MilitaryElite;

public interface Spy extends Soldier {
    String getCodeNumber();
}
