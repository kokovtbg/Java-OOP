package InterfacesAndAbstraction.exercise.MilitaryElite;

public interface LieutenantGeneral extends Private {
    void addPrivate(PrivateImpl privat);
}
