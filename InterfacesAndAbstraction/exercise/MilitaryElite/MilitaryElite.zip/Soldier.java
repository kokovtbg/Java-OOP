package InterfacesAndAbstraction.exercise.MilitaryElite;

public interface Soldier {
    int getId();
    String getFirstName();
    String getLastName();
}
