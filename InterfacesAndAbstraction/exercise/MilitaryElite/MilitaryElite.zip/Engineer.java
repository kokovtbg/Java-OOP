package InterfacesAndAbstraction.exercise.MilitaryElite;

public interface Engineer extends SpecialisedSoldier {

}
