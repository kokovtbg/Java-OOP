//package InterfacesAndAbstraction.exercise.BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
