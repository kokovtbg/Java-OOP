//package InterfacesAndAbstraction.exercise.BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
