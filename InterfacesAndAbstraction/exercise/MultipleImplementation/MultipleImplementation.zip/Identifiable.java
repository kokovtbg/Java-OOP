//package InterfacesAndAbstraction.exercise.MultipleImplementation;

public interface Identifiable {
    String getId();
}
