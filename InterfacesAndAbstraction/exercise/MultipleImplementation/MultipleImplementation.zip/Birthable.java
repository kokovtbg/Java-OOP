//package InterfacesAndAbstraction.exercise.MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
