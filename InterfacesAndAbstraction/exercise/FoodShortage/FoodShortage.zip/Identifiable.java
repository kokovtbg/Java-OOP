//package InterfacesAndAbstraction.exercise.FoodShortage;

public interface Identifiable {
    String getId();
}
