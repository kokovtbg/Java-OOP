//package InterfacesAndAbstraction.exercise.FoodShortage;

public interface Person {
    String getName();
    int getAge();
}
