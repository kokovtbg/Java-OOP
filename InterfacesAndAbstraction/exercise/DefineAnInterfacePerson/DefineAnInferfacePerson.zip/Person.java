//package InterfacesAndAbstraction.exercise.DefineAnInterfacePerson;

public interface Person {
    String getName();
    int getAge();
}
