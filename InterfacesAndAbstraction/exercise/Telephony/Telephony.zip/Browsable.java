//package InterfacesAndAbstraction.exercise.Telephony;

public interface Browsable {
    String browse();
}
