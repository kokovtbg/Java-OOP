//package InterfacesAndAbstraction.exercise.Telephony;

public interface Callable {
    String call();
}
