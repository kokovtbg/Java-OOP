package Polymorphism.exercise.WildFarm;

public class Vegetable extends Food {

    protected Vegetable(Integer quantity) {
        super(quantity);
    }
}
