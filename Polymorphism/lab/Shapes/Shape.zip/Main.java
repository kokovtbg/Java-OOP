//package Polymorphism.lab.Shape;

public class Main {
    public static void main(String[] args) {

    }
}
